import { describe, expect, it, beforeEach } from "vitest";
import { createOrder, getOrderByRazorpayOrderId, completeOrder, getOrderByDownloadToken } from "./db";
import type { InsertOrder } from "../drizzle/schema";

describe("Payment Flow Integration", () => {
  let testOrderId: number;
  const testOrderData: InsertOrder = {
    buyerName: "Test Buyer",
    buyerEmail: "test@example.com",
    razorpayOrderId: "order_test_123",
    razorpayPaymentId: "",
    amount: 19900,
    currency: "INR",
    paymentStatus: "pending",
    downloadToken: "token_test_abc123xyz",
  };

  it("should create an order with pending status", async () => {
    const order = await createOrder(testOrderData);
    expect(order).toBeDefined();
    expect(order?.paymentStatus).toBe("pending");
    expect(order?.buyerName).toBe("Test Buyer");
    expect(order?.downloadToken).toBe("token_test_abc123xyz");
    if (order) {
      testOrderId = order.id;
    }
  });

  it("should retrieve order by Razorpay order ID", async () => {
    const order = await getOrderByRazorpayOrderId("order_test_123");
    expect(order).toBeDefined();
    expect(order?.razorpayOrderId).toBe("order_test_123");
    expect(order?.paymentStatus).toBe("pending");
  });

  it("should complete order with payment ID", async () => {
    await completeOrder(testOrderId, "pay_test_456");
    const order = await getOrderByRazorpayOrderId("order_test_123");
    expect(order?.paymentStatus).toBe("completed");
    expect(order?.razorpayPaymentId).toBe("pay_test_456");
  });

  it("should retrieve order by download token after completion", async () => {
    const order = await getOrderByDownloadToken("token_test_abc123xyz");
    expect(order).toBeDefined();
    expect(order?.paymentStatus).toBe("completed");
    expect(order?.razorpayPaymentId).toBe("pay_test_456");
  });

  it("should verify payment ID is persisted correctly", async () => {
    const order = await getOrderByRazorpayOrderId("order_test_123");
    expect(order?.razorpayPaymentId).toBe("pay_test_456");
    expect(order?.razorpayPaymentId).not.toBe("");
  });
});
